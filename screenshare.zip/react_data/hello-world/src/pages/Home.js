import React, { useState, useEffect } from 'react';
import './styles.css';
import axios from 'axios';
import io from 'socket.io-client';

// The URL where the backend is running
const SOCKET_SERVER_URL = 'http://localhost:4000';

const App = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userStatus, setUserStatus] = useState('offline');
  const [socket, setSocket] = useState(null);

  // Create socket connection when the component is mounted
  useEffect(() => {
    const newSocket = io(SOCKET_SERVER_URL, {
      transports: ['websocket'],
    });
    setSocket(newSocket);

    return () => newSocket.close(); // Close socket connection when the component is unmounted
  }, []);

  // Handle login
  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:4000/login', {
        email,
        password,
      });

      // On successful login, emit the login event to the server
      if (response.status === 200) {
        setIsLoggedIn(true);
        setLoginError('');
        socket.emit('login', email); // Notify server about the login
      }
    } catch (error) {
      setLoginError(error.response.data.error);
    }
  };

  // Listen for user status changes
  useEffect(() => {
    if (socket) {
      socket.on('userStatusUpdate', (data) => {
        if (data.userId === email) {
          setUserStatus(data.status);
        }
      });
    }
  }, [socket, email]);

  return (
    <div className="App">
      {!isLoggedIn ? (
        <div>
          <h2>Login</h2>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button onClick={handleLogin}>Login</button>
          {loginError && <p>{loginError}</p>}
        </div>
      ) : (
        <div>
          <h2>Welcome, {email}</h2>
          <p>Status: {userStatus}</p>
        </div>
      )}
    </div>
  );
};

export default App;
